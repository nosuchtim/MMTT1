"""ArcBall navigation/examination demo

Note: requires numpy (code used to work with Numeric, but has since regressed)
"""
