"""Lens flare demo

Note: this demo will not work with Numeric, you will need to have numpy
instead, as the demo uses loose operations for *= /= and the like which 
Numeric could not support.
"""
