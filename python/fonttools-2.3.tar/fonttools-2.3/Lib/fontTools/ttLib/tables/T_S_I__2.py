from fontTools import ttLib

superclass = ttLib.getTableClass("TSI0")

class table_T_S_I__2(superclass):
	
	dependencies = ["TSI3"]

