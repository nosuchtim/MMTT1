import asciiTable

class table_T_S_I_P_(asciiTable.asciiTable):
	pass

