Builds as a standard pure-python package.  The vrml_accelerate module can be built (separately) to provide C extension speedups.
