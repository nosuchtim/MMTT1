"""Empty __init__.py file to signal Python this directory is a package.
(It can't be completely empty since WinZip seems to skip empty files.)
"""
